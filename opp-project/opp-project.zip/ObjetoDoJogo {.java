import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

abstract class ObjetoDoJogo{
    protected Rectangle limites;

    public ObjetoDoJogo(int x, int y, int largura, int altura) {
        limites = new Rectangle(x, y, largura, altura);
    }

    public abstract void desenhar(Graphics g);

    public Rectangle getLimites() {
        return limites;
    }

    public void mover(int dx) {
        limites.x -= dx;
    }

    public void mover(int dx, int dy) {
        limites.x -= dx;
        limites.y += dy;
    }
}