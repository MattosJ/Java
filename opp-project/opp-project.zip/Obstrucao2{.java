import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

class Obstrucao2 extends Obstrucao {
    public Obstrucao2(int x, int altura) {
        // A altura permanece a mesma, mas a coordenada y será sempre 0 para que a obstrução comece do topo.
        super(x, 270 - altura);
        // Ajusta a posição da obstrução para começar do topo
        this.limites.y = 150; // A obstrução começa no topo da tela
        this.limites.height = altura; // Definimos a altura conforme o parâmetro passado
    }

    @Override
    public void desenhar(Graphics g) {
        g.setColor(Color.ORANGE); // Cor da obstrução 2
        g.fillRect(limites.x, limites.y, limites.width, limites.height);
    }
}
